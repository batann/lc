#!/bin/bash
dialog --title "IN PROGRESS" --msgbox "Mdify themes.sh script" 0 0
sudo -u batan bash settings.sh
