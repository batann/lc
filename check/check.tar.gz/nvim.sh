options=(  "vimwiki "   "vim-taskwarrior "   "taskwiki "   "tabular "   "calendar-vim "   "tagbar "   "vim-plugin-AnsiEsc "   "vim-table-mode "   "deoplete.nvim  "   "emmet-vim "   "ale  "   "html.vim  "   "vim-surround"   "vim-lsp "   "vim-lsp-ale "   "prettier  "   "unite.vim "   "awesome-vim-colorschemes " )

		0)
	echo "Installing Vimwiki"
	git clone https://github.com/vimwiki/vimwiki.git /home/batan/.config/nvim/pack/plugins/start/vimwiki
	;;

	1)
 echo "Installing vim-taskwarrior"
	git clone https://github.com/farseer90718/vim-taskwarrior /home/batan/.config/nvim/pack/plugins/start/vim-taskwarrior
	;;
	2)
 echo "Installing taskwiki"
	git clone https://github.com/tools-life/taskwiki.git /home/batan/.config/nvim/pack/plugins/start/taskwiki --branch dev
	;;

	3)
 echo "Installing tabular"
	git clone https://github.com/godlygeek/tabular.git /home/batan/.config/nvim/pack/plugins/start/tabular
	;;

	4)
 echo "Installing calendar-vim"
	git clone https://github.com/mattn/calendar-vim.git /home/batan/.config/nvim/pack/plugins/start/calendar-vim
	;;

	5)
 echo "Installing tagbar"
	git clone https://github.com/majutsushi/tagbar /home/batan/.config/nvim/pack/plugins/start/tagbar
	;;

	6)
 echo "Installing vim-plugin-AnsiEsc"
	git clone https://github.com/powerman/vim-plugin-AnsiEsc /home/batan/.config/nvim/pack/plugins/start/vim-plugin-AnsiEsc
	;;

	7)
 echo "Installing vim-table-mode"
		git clone https://github.com/dhruvasagar/vim-table-mode.git /home/batan/.config/nvim/pack/plugins/start/table-mode
		;;

		8)
 echo "Installing deoplete.nvim"
			git clone https://github.com/Shougo/deoplete.nvim.git /home/batan/.config/nvim/pack/plugins/start/deoplete
			;;

		9 )
 echo "Installing emmet-vim"
			git clone https://github.com/mattn/emmet-vim.git /home/batan/.config/nvim/pack/plugins/start/emmet-vim
			;;

		10)
 echo "Installing ale"
			git clone https://github.com/dense-analysis/ale.git /home/batan/.config/nvim/pack/plugins/start/ale
			;;

		11)
 echo "Installing html5.vim"
			git clone https://github.com/othree/html5.vim.git /home/batan/.config/nvim/pack/plugins/start/html5.vim
			;;

		12)
 echo "Installing vim-surround"
				git clone https://github.com/tpope/vim-surround.git /home/batan/.config/nvim/pack/plugins/start/surround-vim
				;;

		13)
 echo "Installing vim-lsp"
				git clone https://github.com/prabirshrestha/vim-lsp /home/batan/.config/nvim/pack/plugins/start/vim-lsp.git
				;;

		14)
 echo "Installing vim-lsp-ale "
				git clone https://github.com/rhysd/vim-lsp-ale.git /home/batan/.config/nvim/pack/plugins/start/vim-lsp-ale.git
				;;

		15)
 echo "Installing prettier"
				git clone https://github.com/prettier/prettier.git /home/batan/.config/nvim/pack/plugins/start/prettier/
				;;

		16)
 echo "Installing unite.vim"
				git clone https://github.com/Shougo/unite.vim.git /home/batan/.config/nvim/pack/plugins/start/unite.vim
				;;

		17)
 echo "Installing awsome-vim-colorschemes"
				git clone https://github.com/rafi/awesome-vim-colorschemes.git /home/batan/.config/nvim/pack/plugins/start/awsome-vim-colorschemes
				;;
