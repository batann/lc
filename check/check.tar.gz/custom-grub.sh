#!/bin/bash
#############################################################
#name:
#description:
#author: Fairdinkum Batan
#date:
#############################################################
/usr/bin/xterm -fa 'Terminus' -fs 9 -geom 50x30+0+0 -e bash -c "sudo bash /home/batan/100/Top-5-Bootloader-Themes/install.sh"


