#!/bin/bash
#
xclip -o >> /home/batan/book.txt
echo -e "" >> /home/batan/book.txt

