# @aws-sdk/invalid-dependency

[![NPM version](https://img.shields.io/npm/v/@aws-sdk/invalid-dependency/latest.svg)](https://www.npmjs.com/package/@aws-sdk/invalid-dependency)
[![NPM downloads](https://img.shields.io/npm/dm/@aws-sdk/invalid-dependency.svg)](https://www.npmjs.com/package/@aws-sdk/invalid-dependency)

> An internal package

## Usage

You probably shouldn't, at least directly.
