# @aws-sdk/signature-v4

[![NPM version](https://img.shields.io/npm/v/@aws-sdk/signature-v4/latest.svg)](https://www.npmjs.com/package/@aws-sdk/signature-v4)
[![NPM downloads](https://img.shields.io/npm/dm/@aws-sdk/signature-v4.svg)](https://www.npmjs.com/package/@aws-sdk/signature-v4)
