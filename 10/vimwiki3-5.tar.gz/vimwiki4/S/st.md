<h3 align="center">
	Tokyonight for <a href="https://st.suckless.org/">st</a>
</h3>

### About

This port offers the colors needed for ST's header file.

### Usage

1. Choose your flavour.
2. Copy the contents of `flavor.h` and replace into your st build's `config.h`.
3. Then `make install` it in st folder.
