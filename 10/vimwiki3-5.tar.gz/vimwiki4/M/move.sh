#!/bin/bash
#############################################################
#name:
#description:
#author: Fairdinkum Batan
#date:
#############################################################

mkdir -p {A..Z}

for file in *; do
    if [[ -f $file ]]; then
        first_letter=$(echo "$file" | cut -c1 | tr 'a-z' 'A-Z')
        mv "$file" "$first_letter/"
    fi
done
