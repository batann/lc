# @aws-sdk/chunked-blob-reader

[![NPM version](https://img.shields.io/npm/v/@aws-sdk/chunked-blob-reader/latest.svg)](https://www.npmjs.com/package/@aws-sdk/chunked-blob-reader)
[![NPM downloads](https://img.shields.io/npm/dm/@aws-sdk/chunked-blob-reader.svg)](https://www.npmjs.com/package/@aws-sdk/chunked-blob-reader)

> An internal package

## Usage

You probably shouldn't, at least directly.
