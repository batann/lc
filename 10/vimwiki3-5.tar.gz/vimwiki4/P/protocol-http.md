# @aws-sdk/protocol-http

[![NPM version](https://img.shields.io/npm/v/@aws-sdk/protocol-http/latest.svg)](https://www.npmjs.com/package/@aws-sdk/protocol-http)
[![NPM downloads](https://img.shields.io/npm/dm/@aws-sdk/protocol-http.svg)](https://www.npmjs.com/package/@aws-sdk/protocol-http)
