# @aws-sdk/eventstream-serde-node

[![NPM version](https://img.shields.io/npm/v/@aws-sdk/eventstream-serde-node/latest.svg)](https://www.npmjs.com/package/@aws-sdk/eventstream-serde-node)
[![NPM downloads](https://img.shields.io/npm/dm/@aws-sdk/eventstream-serde-node.svg)](https://www.npmjs.com/package/@aws-sdk/eventstream-serde-node)

> An internal package

## Usage

You probably shouldn't, at least directly.
