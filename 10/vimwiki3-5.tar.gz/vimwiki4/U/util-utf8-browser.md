# @aws-sdk/util-utf8-browser

[![NPM version](https://img.shields.io/npm/v/@aws-sdk/util-utf8-browser/latest.svg)](https://www.npmjs.com/package/@aws-sdk/util-utf8-browser)
[![NPM downloads](https://img.shields.io/npm/dm/@aws-sdk/util-utf8-browser.svg)](https://www.npmjs.com/package/@aws-sdk/util-utf8-browser)

> Deprecated package
>
> This internal package is deprecated in favor of [@aws-sdk/util-utf8](https://www.npmjs.com/package/@aws-sdk/util-utf8).
