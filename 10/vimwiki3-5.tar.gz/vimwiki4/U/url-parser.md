# @aws-sdk/url-parser

[![NPM version](https://img.shields.io/npm/v/@aws-sdk/url-parser/latest.svg)](https://www.npmjs.com/package/@aws-sdk/url-parser)
[![NPM downloads](https://img.shields.io/npm/dm/@aws-sdk/url-parser.svg)](https://www.npmjs.com/package/@aws-sdk/url-parser)

> An internal package

## Usage

You probably shouldn't, at least directly.
