# @aws-sdk/node-http-handler

[![NPM version](https://img.shields.io/npm/v/@aws-sdk/node-http-handler/latest.svg)](https://www.npmjs.com/package/@aws-sdk/node-http-handler)
[![NPM downloads](https://img.shields.io/npm/dm/@aws-sdk/node-http-handler.svg)](https://www.npmjs.com/package/@aws-sdk/node-http-handler)
