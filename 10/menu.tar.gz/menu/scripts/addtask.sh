#!/bin/bash

read abc

task add $abc
send-notify -t 5000 "tasks" "<span color='Yellow' font='14px'>$(task list)</span>

