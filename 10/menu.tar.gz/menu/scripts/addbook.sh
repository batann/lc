#!/bin/bash


clear
bcd=$(date +%j)
read -p 'URL:    '  abc
buku -a $abc +$bcd
