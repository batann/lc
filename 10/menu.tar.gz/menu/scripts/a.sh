#!bin/bash

options=$(ls /home/batan/10/menu/scripts/); select software in ${options[@]}; do sudo -u batan bash /home/batan/10/menu/scripts/$software; done
