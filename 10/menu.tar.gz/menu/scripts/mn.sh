#!/bin/bash


clear
echo "================"
echo "= Manual Page ?="
echo "================"
read abc
man2html /usr/share/man/man1/$abc.1.gz> /home/batan/10/html/man/$abc.html
sed -i '5i <link rel="stylesheet" type="text/css" href="/home/batan/10/html/man/styles.css" />' /home/batan/10/html/man/$abc.html
falkon /home/batan/10/html/man/$abc.html &&
	rm /home/batan/10/html/man/index.html &&
	tree /home/batan/10/html/man -H /home/batan/10/html/man/ -T Manualpages -C -o ~/10/html/man/index.html &&
	sed -i '5i <link rel="stylesheet" type="text/css" href="/home/batan/10/html/man/styles.css" />' /home/batan/10/html/man/index.html


sleep 1sec
