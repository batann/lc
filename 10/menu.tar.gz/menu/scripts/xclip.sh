#!/bin/bash
#############################################################
#name:
#description:
#author: Fairdinkum Batan
#date:
#############################################################
dddd=$(date +%j%H%M)
clear
xclip -o >>temp.txt

if [[ -f /home/batan/.local/bin/edge-tts ]]; then

	/home/batan/.local/bin/edge-tts -f temp.txt --write-media output.mp3
	/usr/bin/play output.mp3
else

/home/batan/edge-tts/bin/edge-tts -f temp.txt --write-media output.mp3
/usr/bin/play output.mp3
rm output.mp3
rm temp.txt
fi
clear

