#!/bin/bash

Black="\033[0;30m"
Red="\033[0;31m"
Green="\033[0;32m"
Blue="\033[0;34m"
Purple="\033[0;35m"
Cyan="\033[0;36m"
Yellow="\033[1;33m"
White="\033[1;37m"
NC="\033[0m"



clear
echo -e ""
echo -e "${Yellow}===================================="
echo -e "${Yellow}===  ${Purple}Directory to be backed up?  ${Yellow}==="
echo -e "${Yellow}===================================="
echo -e "${Purple}"
read abc
bcd=$(date +%j)

DIR=/media/100/$abc
if test -f "$DIR";then


	sudo mv /media/100/$abc /media/100/$abc.$bcd
fi
sudo mkdir /media/100/$abc
sudo chown -R batan:batan /media/100/$abc
tar vfcz /media/100/$abc/$abc.$bcd.tar.gz $abc
clear
echo -e "${Cyan}"
echo -e "${Yellow}===================================="
echo -e "${Yellow}=== ${Purple}Contents of ${Cyan}/media/100/$abc:"
echo -e "${Yellow}===================================="
echo -e "${Cyan}"
cde=$(ls /media/100/$abc/)
echo -e "${Green}         $cde"
echo -e "${Cyan}"
read  -n 1 -p "Continue?" mainmenuinput
clear
echo -e ""
echo -e "${Yellow}======================================"
echo -e "${Yellow}===   ${Cyan}Backup another directory?${Yellow}   ==="
echo -e "${Yellow}======================================"
echo -e ""
echo -e "${Green}>>> ${Yellow}Y ${Cyan}Yes"
echo -e "${Green}>>> ${Yellow}N ${Cyen}No"
echo -e ""
read cde
if [[ $cde -eq y ]]; then
	sudo -u batan  bash /home/batan/10/menu/scripts/back.sh
else
read  -n 1 -p "Press Any Button" mainmenuinput
echo "Backups to media 100 done."
fi
