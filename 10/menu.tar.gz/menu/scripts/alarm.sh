#!/bin/bash
#############################################################
#name:
#description:
#author: Fairdinkum Batan
#date:
#############################################################
#   ANSI CODE   ##################################################################
Black='\033[0;30m'
Red='\033[0;31m'
Green='\033[0;32m'
Blue='\033[0;34m'
Purple='\033[0;35m'
Cyan='\033[0;36m'
Yellow='\033[1;33m'
White='\033[1;37m'
NC='\033[0m'
############################################################################

TMP_SCRIPT=$(mktemp /tmp/download.mp3.XXXXXXX)
cat << 'EOL' > "$TMP_SCRIPT"
#!/usr/bin/env/ bash
transset -a
fff=$(wmctrl -l|tail -n1|awk '{print $1}') 
toggle-decorations $fff
clear
tput cup 0 0
echo  -e  "${Purple}==========================================${Green}"

tput cup 2 0
echo    "${Purple}==========================================${Green}"
tput cup 1 30
echo -e '...minutes'
tput cup 1 0
read -p '   Set the alarm for...   ' bcd
sleep ${bcd}m && 
notify-send --icon=clockify -t 0000 "Time" "<span color='Yellow' font='94px'>Time is $(date +%H:%M)\nGet Going</span>"
/usr/bin/mpv $HOME/100/sounds/*



EOL
/usr/bin/xterm -fa 'Terminus' -fs 8 -geom 45x4+400+400 -e bash -c "sudo -u batan bash $TMP_SCRIPT"

