#!/bin/bash
top -o %CPU | head -n 12 | sed -n '7,12p'|awk '{print $2,"|"$3,"|"$10,"|"$11}'|column -t|csvlook
