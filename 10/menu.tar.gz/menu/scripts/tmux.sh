#!/bin/bash


xfce4-terminal --geometry=220x60+0+0 -e "tmux new-session 'vim -c :Lexplore'  \; splitw -v -p20  'neomutt' \; selectp -t0 \; splitw -h -p70 \; splitw -v -p30  \; selectp -t1 \; splitw -h -p20 'sudo -u batan bash /home/batan/16/sh/LL.sh' \; selectp -t1 \; splitw -h -p80 'ddgr' \; send-keys -t5 ' ' Enter \; "
