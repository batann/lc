#!/bin/bash
#ANSI CODE##################################################################
Black='\033[0;30m'
Red='\033[0;31m'
Green='\033[0;32m'
Blue='\033[0;34m'
Purple='\033[0;35m'
Cyan='\033[0;36m'
Yellow='\033[1;33m'
White='\033[1;37m'
NC='\033[0m'

cache='20'
ram='20'
cli='CLI Processes'
ipArray=("192.168.1.35" "192.168.1.36" "192.168.1.37" "192.168.1.38" "192.168.1.39" "192.168.1.40")

batanovski=$(for ip in "${ipArray[@]}"; do
if ping -c 2 $ip > /dev/null 2>&1; then
echo ${Green}"$ip ${Purple}is Active.${NC}"
else
echo "${Red}$ip is Inactive.${NC}"|grep 'Active'
fi
done)

#ips=$(sudo -u batan bash /home/batan/10/menu/scripts/ping_local.sh)
while true;do
clear
first_line=$(ps -Ao pid,spid,%cpu,%mem,tty,user,comm --sort=-%cpu|head -n10| sed -n '1p')
second_line=$(ps -Ao pid,spid,%cpu,%mem,tty,user,comm --sort=-%cpu|head -n10|sed -n '2,7p')
third_line=$(free -h|awk '{print $20,$1,$2,$3,$4,$30,$6}'|column -t|sed -n '1p')
fourth_line=$(free -h|awk '{print $1,$2,$3,$4,$5,$6}'|column -t|sed -n '2,3p')
fifth_line=$(ps -T |sed -n '1p')
sixth_line=$(ps -T |sed -n '2,8p')

echo -e "${Blue}+----------------------------------------------------------+"
echo -e "${White}                   === Resource Monitor ==="
echo -e "${Blue}+----------------------------------------------------------+"
echo -e "${Red}ram    ${third_line}"
echo -e "${Yellow}${fourth_line}"
echo -e "${Blue}+----------------------------------------------------------+"
echo -e "${Red}${first_line}"
echo -e "${Cyan}${second_line}"
echo -e "${Blue}+----------------------------------------------------------+"
echo -e "${White}                     === $cli ===           "
echo -e "${Red}${fifth_line}"
echo -e "${Cyan}${sixth_line}"
echo -e "${Blue}+----------------------------------------------------------+"
echo -e "${White}           Host IP:${Green}   $(hostname -I|cut -c 1-13)"
echo -e            "          ${Blue}+-------------------------+"
echo -e "${Blue}Local IPs: "
echo -e "${Yellow}${batanovski} "
echo -e "${Blue}+----------------------------------------------------------+"

sleep 0.9;
done
