cp *.sh /media/batan/home/batan/* /media/batan/home/batan/10/
cp *.sh /media/batan/Q4OS/home/batan/* /media/batan/home/batan/10/
cp *.sh /media/batan/HYBR/home/batan/* /media/batan/home/batan/10/
cp *.sh /media/batan/HOME/batan/* /media/batan/home/batan/10/
cp *.sh /media/batan/home/batan/
cp *.sh /media/batan/Q4OS/home/batan/
cp *.sh /media/batan/HYBR/home/batan/
cp *.sh /media/batan/HOME/batan/
cp *.sh /media/batan/home/batan/* /media/batan/home/batan/10/menu/
cp *.sh /media/batan/Q4OS/home/batan/* /media/batan/home/batan/10/menu/
cp *.sh /media/batan/HYBR/home/batan/* /media/batan/home/batan/10/menu/
cp *.sh /media/batan/HOME/batan/* /media/batan/home/batan/10/menu/
cp *.sh /media/batan/home/batan/* /media/batan/home/batan/10//menu/scripts
cp *.sh /media/batan/Q4OS/home/batan/* /media/batan/home/batan/10//menu/scripts
cp *.sh /media/batan/HYBR/home/batan/* /media/batan/home/batan/10//menu/scripts
cp *.sh /media/batan/HOME/batan/* /media/batan/home/batan/10//menu/scripts
cp *.sh /media/batan/home/batan/* /media/batan/home/batan/10/postinstall/
cp *.sh /media/batan/Q4OS/home/batan/* /media/batan/home/batan/10/postinstall/
cp *.sh /media/batan/HYBR/home/batan/* /media/batan/home/batan/10/postinstall/
cp *.sh /media/batan/HOME/batan/* /media/batan/home/batan/10/postinstall/
