#!/bin/bash
Green='\033[0;32m'
Black='\033[0;30m'
Red='\033[0;31m'
Black='\033[0;32m'
Gray='\033[0;34m'
Purple='\033[0;35m'
Cyan='\033[0;36m'
Yellow='\033[1;33m'
White='\033[1;37m'
NC='\033[0m'
tput civis
#86400 sec per day
clear
echo -e "${Cyan}"
echo -e " Time Now: $(date +%H:%M)" ${Green}
read -p 'Enter Time HH:MM ' abc
cde=$(date --date $abc +%s)
bcd=$(date "+%s")
  if  [[ bcd > cde ]];then
	  efg=$(( cde += 86400))
	xxx=$(( efg -= bcd ))

#	xxx=secondes to be counted

for i in $(seq -f "%4g" $xxx -1 0); do
        clear
    echo -e "${Cyan}=========================="
    echo -e "   ${Yellow}$i ${Green}Seconds to Go"
    echo -e "${Cyan}=========================="
        sleep 1
    done
    (speaker-test -t sine -f 1000) & pid=$! ; sleep 30s ; kill -9 $pid

else

	xxx=$(( cde -= bcd ))
for i in $(seq -f "%4g" $xxx -1 0); do
        clear
    echo -e "${Cyan}=========================="
    echo -e "   ${Yellow}$i ${Green}Seconds to Go"
    echo -e "${Cyan}=========================="
        sleep 1
    done
  fi
