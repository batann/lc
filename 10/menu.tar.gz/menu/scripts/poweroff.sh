#!/bin/bash
#author:batan
#description:shutdown preoces
#date :318

abc="/home/batan/.cache/mozilla/firefox/*"
sudo apt autoremove --purge
sudo apt autoclean
sudo apt clean
if [[ -f "$abc" ]]; then
  sudo rm -r /home/batan/.cache/mozilla/firefox/*
else
  sudo echo 1 >/proc/sys/vm/drop_caches
  sudo echo 2>/proc/sys/vm/drop_caches
  find  ~/.cache/thumbnails -type -f -name '*.png' -exec shred -u -z -f -n 1 {} \;
  sudo swapoff -a &&
    sudo sqappon -a
  sudo poweroff


