#!/bin/bash
#############################################################
#name:
#description:
#author: Fairdinkum Batan
#date:
#############################################################
#!/bin/bash

clear

options=($(ls))
selected=0
total=${#options[@]}

function show_menu() {
    for ((i=0; i<$total; i++)); do
        if [ $i -eq $selected ]; then
            echo -e "\e[1m\e[32m-> ${options[$i]}\e[0m"
        else
            echo "   ${options[$i]}"
        fi
    done
}

while true; do
    show_menu
    read -rsn3 key

    case $key in
        $'\e[A') # Up arrow key
            ((selected--))
            if [ $selected -lt 0 ]; then
                selected=$((total - 1))
            fi
            ;;
        $'\e[B') # Down arrow key
            ((selected++))
            if [ $selected -ge $total ]; then
                selected=0
            fi
            ;;
        $'\x0A') # Enter key
            clear
            if [ $selected -eq $((total - 1)) ]; then
                echo "Exiting..."
                exit 0
            else
                echo "You selected: ${options[$selected]}"
                echo "Perform the action related to this option."
                # Add your actions based on the selected option here
                # For now, this just goes back to the menu
                read -rsn1 -p "Press any key to continue..."
            fi
            ;;
    esac
    clear
done
