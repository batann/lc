#!/bin/bash
Black='\033[0;30m'
Red='\033[0;31m'
Green='\033[0;32m'
Blue='\033[0;34m'
Purple='\033[0;35m'
Cyan='\033[0;36m'
Yellow='\033[1;33m'
White='\033[1;37m'
NC='\033[0m'
###############################################
clear
TMP_SCRIPT=$(mktemp /tmp/countdown_script.XXXXXX)
cat << 'EOL' > "$TMP_SCRIPT"
###############################################
#!/usr/bin/env bash
#   ANSI CODE   ###############################
Black='\033[0;30m'
Red='\033[0;31m'
Green='\033[0;32m'
Blue='\033[0;34m'
Purple='\033[0;35m'
Cyan='\033[0;36m'
Yellow='\033[1;33m'
White='\033[1;37m'
NC='\033[0m'
###############################################
clear
tput civis
echo -e ${Cyan}"==================================="
echo -e "${Purple}   >>>${Green}   Document to move:${Purple}  <<<"
echo -e "${NC}"
echo -e ${Cyan}"==================================="${Purple}
tput cup 2 3
read -p '>>>   ' abc
echo -e "[[$abc]]" >> /home/batan/10/vimwiki/vimwiki5/index.wiki
mv ${abc}.wiki /home/batan/10/vimwiki/vimwiki5/
tput cup 2 6
tput el
tput cup 2 3
echo -e "${Purple}>>>${Green} Push${Purple} [Any]${Green} for Index${Purple} <<<"
read -n1 mmm
xterm -geom 90x40+0-0 -e "vim /home/batan/10/vimwiki/vimwiki5/index.wiki"










EOL
/usr/bin/xterm -geom 90x40+0+0 -e "sudo -u batan bash $TMP_SCRIPT"

