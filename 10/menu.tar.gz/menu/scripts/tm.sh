#!/bin/bash

abc=$(tmux new-session \; splitw -v -p40 \; splitw -h \; selectp -t0 \; splitw -h -p70 'sudo -u batan bash /home/batan/16/sh/LL.sh' \; splitw -h -p80 \; splitw -v -p30 \; selectp -t2 \; splitw -h -p30 'sudo -u batan bash /home/batan/16/sh/menu.sh' \;)
printf $abc
