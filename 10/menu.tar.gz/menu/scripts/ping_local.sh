#!/bin/bash
alias mkdir='mkdir -p'

#   ANSI CODE   ##################################################################
Black='\033[0;30m'
Red='\033[0;31m'
Green='\033[0;32m'
Blue='\033[0;34m'
Purple='\033[0;35m'
Cyan='\033[0;36m'
Yellow='\033[1;33m'
White='\033[1;37m'
NC='\033[0m'

ipArray=("192.168.1.35" "192.168.1.36" "192.168.1.37" "192.168.1.38" "192.168.1.39" "192.168.1.40")
clear
xxx=$(hostname -I|cut -c 1-12)
echo -e ${Red}'+----------------------------------------------------------------+'
echo -e ${Cyan}'                        Your  IP  is:'
echo -e '                       '${Blue}   $xxx''
echo -e ${Red}'+----------------------------------------------------------------+'
for ip in ${ipArray[@]}; do
	if ping -c 2 $ip > /dev/null 2>&1; then
echo -e ${Green}"     			 ->" $ip ${Purple} "is Active. "${NC}
else
echo -e ${Green} $ip 'is Inactive'${NC}
fi
done
echo -e ${Red}'+----------------------------------------------------------------+'
echo -e ${Cyan}'   Attempt to establish a Connection with the Local Machine'
echo -e ${Red}'+----------------------------------------------------------------+'
echo -e ${Green}'			>>>'${Blue} '1'${Red}')'${White}'	Yes'
echo -e ${Green}'			>>>'${Blue} '2'${Red}')'${White}'	No'
read -p '			     1/2 ' yyy
clear
if [[ $yyy -eq 2 ]]; then
	tput cup 2 15
	echo "Thank You"
	exit 0
else
	clear
echo -e'${Red}' '+----------------------------------------------------------------+'
echo -e '${Red}''    Please choose the type of connection Youd Like to establish:  '
echo -e '			>>> 1) ssh'
echo -e '${Red}''+----------------------------------------------------------------+'
echo -e '${Red}''+----------------------------------------------------------------+'
read	-p '		Please enter your prefered choice' ccc
fi
if [[ $ccc -eq 1 ]]; then
	echo ""
else
	exit 0
fi
