 #/bin/bash


		E='echo -e';e='echo -en';trap "R;exit" 2
		ESC=$( $e "\e")
		TPUT(){ $e "\e[${1};${2}H";}
		CLEAR(){ $e "\ec";}
		CIVIS(){ $e "\e[?25l";}
		DRAW(){ $e "\e%@\e(0";}
		WRITE(){ $e "\e(B";}
		MARK(){ $e "\e[7m";}
		UNMARK(){ $e "\e[27m";}
		R(){ CLEAR ;stty sane;$e "\ec\e[30;44m\e[J";};
		HEAD(){ DRAW
			for each in $(seq 1 30);do
			$E " x                      x"
			done
			WRITE;MARK;TPUT 1 5
			$E "  Usefull Software  ";UNMARK;}
			i=0; CLEAR; CIVIS;NULL=/dev/null
			HEAD2(){ MARK;TPUT 11 5
			printf " Custom Scripts    ";UNMARK;}
			HEAD3(){ MARK;TPUT 22 5
			printf " Ba7an@tutanota.com";UNMARK;}
			FOOT(){ MARK;TPUT 30 5
			printf " Privacy Matters   ";UNMARK;}
			ARROW(){ read -s -n3 key 2>/dev/null >&2
			if [[ $key = $ESC[A ]];then echo up;fi
			if [[ $key = $ESC[B ]];then echo dn;fi;}

		M0(){ TPUT 3 10; $e "MegaSync";}
	    	M1(){ TPUT 4 10; $e "DDGR";}
	    	M2(){ TPUT 5 10; $e "Terminal";}
	    	M3(){ TPUT 6 10; $e "Terminal";}
	    	M4(){ TPUT 7 10; $e "Falkon";}
	    	M5(){ TPUT 8 10; $e "Firefox";}
		M6(){ TPUT 9 10; $e "Drun";}
		M7(){ TPUT 10 10; $e "Turtle";}
		M8(){ TPUT 13 10; $e "Note";}
		M9(){ TPUT 14 10; $e "Chess";}
		M10(){ TPUT 15 10; $e "Calendar";}
		M11(){ TPUT 16 10; $e "TW";}
		M12(){ TPUT 17 10; $e "VimL";}
		M13(){ TPUT 18 10; $e "Ranger";}
		M14(){ TPUT 19 10; $e "Vimwiki";}
		M15(){ TPUT 20 10; $e "SplitV";}
		M16(){ TPUT 24 10; $e "MegaCloud";}
		M17(){ TPUT 25 10; $e "SplitWindow";}
		M18(){ TPUT 26 10; $e "F - ";}
		M19(){ TPUT 27 10; $e "DashBoard";}
		M20(){ TPUT 28 10; $e "EXIT   ";}
		    LM=20
   MENU(){ for each in $(seq 0 $LM);do M${each};done;}
   POS(){ if [[ $cur == up ]];then ((i--));fi
           if [[ $cur == dn ]];then ((i++));fi
           if [[ $i -lt 0   ]];then i=$LM;fi
           if [[ $i -gt $LM ]];then i=0;fi;}
	REFRESH(){ after=$((i+1)); before=$((i-1))
           if [[ $before -lt 0  ]];then before=$LM;fi
           if [[ $after -gt $LM ]];then after=0;fi
           if [[ $j -lt $i      ]];then UNMARK;M$before;else UNMARK;M$after;fi
           if [[ $after -eq 0 ]] || [ $before -eq $LM ];then
           UNMARK; M$before; M$after;fi;j=$i;UNMARK;M$before;M$after;}
	INIT(){ R;HEAD;HEAD2;HEAD3;FOOT;MENU;}
     SC(){ REFRESH;MARK;$S;$b;cur=`ARROW`;}
     ES(){ MARK;$e "ENTER = main menu ";$b;read;INIT;};INIT
	while [[ "$O" != " " ]]; do case $i in


        0) S=M0;SC;if [[ $cur == "" ]];then R;$e "\n$(notify-send -t 7000 "Megasync" "<span color='White' font='14px'>$(megals)</span>")\n";ES;fi;;
	1) S=M1;SC;if [[ $cur == "" ]];then R;$e "\n$(xfce4-terminal --hide-scrollbar --hide-menubar --hide-borders --zoom=-2 --geometry=100x62+20+20 -e 'ddgr')\n";ES;fi;;
        2) S=M2;SC;if [[ $cur == "" ]];then R;$e "\n$(xfce4-terminal --geometry=120x60+900-100 --hide-menubar --hide-scrollbar --hide-borders --zoom=-1.5 )\n";ES;fi;;
        3) S=M3;SC;if [[ $cur == "" ]];then R;$e "\n$(xfce4-terminal --geometry=120x40+0-0)\n";ES;fi;;
        4) S=M4;SC;if [[ $cur == "" ]];then R;$e "\n$(falkon)\n";ES;fi;;
        5) S=M5;SC;if [[ $cur == "" ]];then R;$e "\n$(firefox)\n";ES;fi;;
		6) S=M6;SC;if [[ $cur == "" ]];then R;$e "\n$(rofi -show drun)\n";ES;fi;;
		7) S=M7;SC;if [[ $cur == "" ]];then R;$e "\n$(/opt/turtl/turtl)\n";ES;fi;;
		8) S=M8;SC;if [[ $cur == "" ]];then R;$e "\n$(xfce4-terminal --geometry=80x50+1300-0 --color-bg=Black --color-text=Green -e 'vim +start /home/batan/16/note/1000.txt')\n";ES;fi;;
		9) S=M9;SC;if [[ $cur == "" ]];then R;$e "\n$(falkon chess.com)\n";ES;fi;;
		10) S=M10;SC;if [[ $cur == "" ]];then R;$e "\n$(xfce4-terminal --geometry=100x30+0+0 --hide-borders --hide-scrollbar --hide-menubar -e 'vim -c :Calendar')\n";ES;fi;;
		11) S=M11;SC;if [[ $cur == "" ]];then R;$e "\n$(xfce4-terminal --geometry=100x30+0+0 --hide-borders --hide-scrollbar --hide-menubar -e 'vim -c :TW')\n";ES;fi;;
		12) S=M12;SC;if [[ $cur == "" ]];then R;$e "\n$(xfce4-terminal --geometry=100x30+0+0 --hide-borders --hide-scrollbar --hide-menubar -e 'vim -c :Lexplore')\n";ES;fi;;
		13) S=M13;SC;if [[ $cur == "" ]];then R;$e "\n$(xfce4-terminal --geometry=100x30+0+0 --hide-borders --hide-scrollbar --hide-menubar -e 'ranger')\n";ES;fi;;
		14) S=M14;SC;if [[ $cur == "" ]];then R;$e "\n$(sudo -u batan bash /home/batan/16/sh/wikk.sh)\n";ES;fi;;
		15) S=M15;SC;if [[ $cur == "" ]];then R;$e "\n$(tmux killp -t2 \; splitw -h -p70 'fortune' )\n";ES;fi;;
		16) S=M16;SC;if [[ $cur == "" ]];then R;$e "\n$(abc=$(megals) && notify-send -t 10000 'Mega' "<span color='White' font='14px'>$abc</span>" )\n";ES;fi;;
		17) S=M17;SC;if [[ $cur == "" ]];then R;$e "\n$(tmux splitw -t1 -h -p70)\n";ES;fi;;
		18) S=M18;SC;if [[ $cur == "" ]];then R;$e "\n$(echo 'Really,Peter'|festival --tts)\n";ES;fi;;
		19) S=M19;SC;if [[ $cur == "" ]];then R;$e "\n$(xfce4-terminal --geometry=220x60-0-0 -e "tmux new-session \; splitw -v -p40 \; splitw -h \; selectp -t0 \; splitw -h -p70 'sudo -u batan bash /home/batan/16/menu/menu1.sh' \; splitw -h -p75 \; splitw -v -p30 \; selectp -t2 \; splitw -h -p30 'sudo -u batan bash /home/batan/16/menu/menu2.sh'"
 )\n";ES;fi;;
		20) S=M20;SC;if [[ $cur == "" ]];then R;exit 0;fi;;

  esac;POS;done
