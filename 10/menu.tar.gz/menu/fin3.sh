#!/bin/bash


				mkdir -p /home/batan/.config/nvim/pack/plugins/start/
				mkdir -p /home/batan/.vim/pack/plugins/start/

dialog --backtitle "Your friendly Postinstall Script" --title "Hi there!" --msgbox "Hold on to your heameroids and relax,
dont panic, I am here to help!" 10 60


if [[ $EUID -ne 0 ]]; then
   	echo "This script must be run as root"
   	exit 1
else
	#Update and Upgrade
	echo "Updating and Upgrading"
#	apt-get update && sudo apt-get upgrade

	sudo apt-get install dialog
	cmd=(dialog --separate-output --checklist "Please Select Software you want to install:" 40 76 30)
	options=(    # any option can be set to default to "on"
		 59 "vimwiki" off
		 41 "vim-taskwarrior" off
		 42 "taskwiki" off
		 43 "tabular" off
		 44 "calendar" off
		 45 "tagbar" off
		 46 "vim-plugin-AnsiEsc" off
		 47 "table-mode" off
		 49 "deoplete" off
		 50 "emmet-vim" off
		 51 "synchronous L engine" off
		 52 "html5.vim" off
		 54 "surround-vim" off
		 55 "vim-lsp" off
		 56 "vim-lsp-ale" off
		 57 "Prettier" off
	         58 "Unite.vim" off
		 65 "speedread" off
		 66 "shalarm" off
		 69 "Mutt Wizard" off
		 113 "Awsom Vim Colorschemes" off
		 114 "ALL VIM plugins" off
        	 116 "ALL NVIM PLUGINS" off
		 120 "!!! LEAVE FEEDBACK" off
		 121 "!!! Run " off



	 )



		choices=$("${cmd[@]}" "${options[@]}" 2>&1 >/dev/tty)
		clear
		for choice in $choices
		do
		    case $choice in

			59)
				#Install Vimwiki
				echo "Installing Vimwiki"
				mkdir /home/batan/.config/nvim/pack
				mkdir /home/batan/.config/nvim/pack/plugins/
				mkdir /home/batan/.config/nvim/pack/plugins/start
				git clone https://github.com/vimwiki/vimwiki.git /home/batan/.config/nvim/pack/plugins/start/vimwiki --branch dev
				nvim -c 'helptags home/batan/.config/nvim/pack/plugins/start/vimwiki/doc' -c quit
				;;

			41)
				#Install Vim-taskwarrior
				echo "Installing Vim-taskwarrior"
				 git clone https://github.com/farseer90718/vim-taskwarrior ~/.config/nvim/pack/plugins/start/vim-taskwarrior
				;;
			42)
				#Install Taskwiki
				echo "Installing Taskwiki"
				git clone https://github.com/tools-life/taskwiki.git /home/batan/.config/nvim/pack/plugins/start/taskwiki --branch dev
				nvim -c 'helptags /home/batan/.config/nvim/pack/plugins/start/taskwiki/doc' -c quit
				;;

			43)
				#Install Tabular
				echo "Installing tagbar"
				git clone https://github.com/godlygeek/tabular.git /home/batan/.config/nvim/pack/plugins/start/tabular
				nvim -c 'helptags ~/.config/nvim/pack/plugins/start/vim-tabular/doc' -c quit
				;;

			44)
				#Install Calendar
				echo "Installing Calendar-vim"
				git clone https://github.com/mattn/calendar-vim.git /home/batan/.config/nvim/pack/plugins/start/calendar-vim
				nvim -c 'helptags ~/.config/nvim/pack/plugins/start/calendar/doc' -c quit
				;;

			45)
				#Install Tagbar
				echo "Installing Tagbar"
				git clone https://github.com/majutsushi/tagbar /home/batan/.config/nvim/pack/plugins/start/tagbar
				nvim -c 'helptags ~/.config/nvim/pack/plugins/start/tagbar/doc' -c quit
				;;
			46)
				#Install Vim-plugin-AnsiEsc
				echo "Not sure why but am installing Vim-plugin-AmsiEsc"
				git clone https://github.com/powerman/vim-plugin-AnsiEsc /home/batan/.config/nvim/pack/plugins/start/vim-plugin-AnsiEsc
				nvim -c 'helptags /home/batan/.config/nvim/pack/plugins/start/vim-plugin-AnsiEsc/doc' -c quit

				;;
			47)
				#Install table-mode
				echo "Installing Table-Mode"
				git clone https://github.com/dhruvasagar/vim-table-mode.git /home/batan/.config/nvim/pack/plugins/start/table-mode
				nvim -c 'helptags /home/batan/.config/nvim/pack/plugins/start/vim-table-mode/doc' -c quit
				;;
			49)
				#deoplete
				echo "cloning a sheep deoplete"
				git clone https://github.com/Shougo/deoplete.nvim.git /home/batan/.config/nvim/pack/plugins/start/deoplete
				;;
			50)
				#emmet-vim
				echo "Installing emmet-vim"
				git clone https://github.com/mattn/emmet-vim.git /home/batan/.config/nvim/pack/plugins/start/emmet-vim
				;;

			51)
				#ale
 				echo "Installing ALE"
				git clone https://github.com/dense-analysis/ale.git /home/batan/.config/nvim/pack/plugins/start/ale
				;;

			52)
				#html5.vim
				echo "Installing html5.vim"
				git clone https://github.com/othree/html5.vim.git /home/batan/.config/nvim/pack/plugins/start/html5.vim
				;;
			54)
				#surround-vim
				echo "installing surround-vim"
				git clone https://github.com/tpope/vim-surround.git /home/batan/.config/nvim/pack/plugins/start/surround-vim
				;;


			55)
				#vim-lsp
				echo "Installing Vim-Lsp"
git clone https://github.com/prabirshrestha/vim-lsp /home/batan/.config/nvim/pack/plugins/start/vim-lsp.git
;;
			56)
				#vim-lsp
				echo "Installing Vim-Lsp-Ale"
git clone https://github.com/rhysd/vim-lsp-ale.git /home/batan/.config/nvim/pack/plugins/start/vim-lsp-ale.git
;;

			57)
				#Prettier
				echo "Installing Prettier"
				git clone https://github.com/prettier/prettier.git ~/.config/nvim/pack/plugins/start/prettier/
				;;

			58)
				#Unite.vim
				echo "Installing Unite.vim"
				git clone https://github.com/Shougo/unite.vim.git ~/.config/nvim/pack/plugins/start/unite.vim
				;;



			65)
				#speedread
				echo "Cloning text reader for dyslexic linux users"
				git clone https://github.com/pasky/speedread.git
				;;
			66)
				#shalarm
				echo "Cloning shalarm"
				git clone https://github.com/jahendrie/shalarm.git
				;;

			69)
				#Mutt-Wizard
				echo "Installing Mutt-Wizard"
				git clone https://github.com/LukeSmithxyz/mutt-wizard
				cd mutt-wizard
				sudo make install
				;;
			113)
				#Awsom Vim COlorschemes
				echo "Cloning Awsom VIm Colorscheems"
				git clone https://github.com/rafi/awesome-vim-colorschemes.git /home/batan/.config/nvim/pack/plugins/start/awsome-vim-colorschemes
				;;
114)
		#VIM PLUGINS
		echo "Installing all VIM Plugins"
git clone https://github.com/vimwiki/vimwiki.git /home/batan/.vim/pack/plugins/start/vimwiki --branch dev
git clone https://github.com/farseer90718/vim-taskwarrior /home/batan/.vim/pack/plugins/start/vim-taskwarrior
git clone https://github.com/tools-life/taskwiki.git /home/batan/.vim/pack/plugins/start/taskwiki --branch dev
git clone https://github.com/godlygeek/tabular.git /home/batan/.vim/pack/plugins/start/tabular
git clone https://github.com/mattn/calendar-vim.git /home/batan/.vim/pack/plugins/start/calendar-vim
git clone https://github.com/majutsushi/tagbar /home/batan/.vim/pack/plugins/start/tagbar
git clone https://github.com/powerman/vim-plugin-AnsiEsc /home/batan/.vim/pack/plugins/start/vim-plugin-AnsiEsc
git clone https://github.com/dhruvasagar/vim-table-mode.git /home/batan/.vim/pack/plugins/start/table-mode
git clone https://github.com/Shougo/deoplete.nvim.git /home/batan/.vim/pack/plugins/start/deoplete
git clone https://github.com/mattn/emmet-vim.git /home/batan/.vim/pack/plugins/start/emmet-vim
git clone https://github.com/dense-analysis/ale.git /home/batan/.vim/pack/plugins/start/ale
git clone https://github.com/othree/html5.vim.git /home/batan/.vim/pack/plugins/start/html5.vim
git clone https://github.com/tpope/vim-surround.git /home/batan/.vim/pack/plugins/start/surround-vim
git clone https://github.com/prabirshrestha/vim-lsp /home/batan/.vim/pack/plugins/start/vim-lsp.git
git clone https://github.com/rhysd/vim-lsp-ale.git /home/batan/.vim/pack/plugins/start/vim-lsp-ale.git
git clone https://github.com/prettier/prettier.git /home/batan/.vim/pack/plugins/start/prettier/
git clone https://github.com/Shougo/unite.vim.git /home/batan/.vim/pack/plugins/start/unite.vim
git clone https://github.com/rafi/awesome-vim-colorschemes.git /home/batan/.vim/pack/plugins/start/awsome-vim-colorschemes
;;



			115)
				#VideoDownloader
				echo "Install Videodownloader"
				flatpak install flathub com.github.unrud.VideoDownloader
				;;
116)
		#NVIM PLUGINS
		echo "Installing all NVIM Plugins"
git clone https://github.com/vimwiki/vimwiki.git /home/batan/.config/nvim/pack/plugins/start/vimwiki --branch dev
git clone https://github.com/farseer90718/vim-taskwarrior /home/batan/.config/nvim/pack/plugins/start/vim-taskwarrior
git clone https://github.com/tools-life/taskwiki.git /home/batan/.config/nvim/pack/plugins/start/taskwiki --branch dev
git clone https://github.com/godlygeek/tabular.git /home/batan/.config/nvim/pack/plugins/start/tabular
git clone https://github.com/mattn/calendar-vim.git /home/batan/.config/nvim/pack/plugins/start/calendar-vim
git clone https://github.com/majutsushi/tagbar /home/batan/.config/nvim/pack/plugins/start/tagbar
git clone https://github.com/powerman/vim-plugin-AnsiEsc /home/batan/.config/nvim/pack/plugins/start/vim-plugin-AnsiEsc
git clone https://github.com/dhruvasagar/vim-table-mode.git /home/batan/.config/nvim/pack/plugins/start/table-mode
git clone https://github.com/Shougo/deoplete.nvim.git /home/batan/.config/nvim/pack/plugins/start/deoplete
git clone https://github.com/mattn/emmet-vim.git /home/batan/.config/nvim/pack/plugins/start/emmet-vim
git clone https://github.com/dense-analysis/ale.git /home/batan/.config/nvim/pack/plugins/start/ale
git clone https://github.com/othree/html5.vim.git /home/batan/.config/nvim/pack/plugins/start/html5.vim
git clone https://github.com/tpope/vim-surround.git /home/batan/.config/nvim/pack/plugins/start/surround-vim
git clone https://github.com/prabirshrestha/vim-lsp /home/batan/.config/nvim/pack/plugins/start/vim-lsp.git
git clone https://github.com/rhysd/vim-lsp-ale.git /home/batan/.config/nvim/pack/plugins/start/vim-lsp-ale.git
git clone https://github.com/prettier/prettier.git /home/batan/.config/nvim/pack/plugins/start/prettier/
git clone https://github.com/Shougo/unite.vim.git /home/batan/.config/nvim/pack/plugins/start/unite.vim
;;




			120)
				#Taking Feedback
				echo :"Taking Feedback"
				;;


			121)
				#Run Script 2
				echo :"Running, unlike Petar, script 2.."
				;;


		esac


	done

				fi
