 #/bin/bash


		E='echo -e';e='echo -en';trap "R;exit" 2
		ESC=$( $e "\e")
		TPUT(){ $e "\e[${1};${2}H";}
		CLEAR(){ $e "\ec";}
		CIVIS(){ $e "\e[?25l";}
		DRAW(){ $e "\e%@\e(0";}
		WRITE(){ $e "\e(B";}
		MARK(){ $e "\e[7m";}
		UNMARK(){ $e "\e[27m";}
		R(){ CLEAR ;stty sane;$e "\ec\e[30;44m\e[J";};
		HEAD(){ DRAW
			for each in $(seq 1 30);do
			$E " x                      x"
			done
			WRITE;MARK;TPUT 1 5
			$E "  Usefull Software  ";UNMARK;}
			i=0; CLEAR; CIVIS;NULL=/dev/null
			HEAD2(){ MARK;TPUT 11 5
			printf " Custom Scripts    ";UNMARK;}
			HEAD3(){ MARK;TPUT 22 5
			printf " Ba7an@tutanota.com";UNMARK;}
			FOOT(){ MARK;TPUT 30 5
			printf " Privacy Matters   ";UNMARK;}
			ARROW(){ read -s -n3 key 2>/dev/null >&2
			if [[ $key = $ESC[A ]];then echo up;fi
			if [[ $key = $ESC[B ]];then echo dn;fi;}

		M0(){ TPUT 3 10; $e "Update";}
	    	M1(){ TPUT 4 10; $e "Upgrade";}
	    	M2(){ TPUT 5 10; $e "List WIFI";}
	    	M3(){ TPUT 6 10; $e "N20";}
	    	M4(){ TPUT 7 10; $e "S20";}
	    	M5(){ TPUT 8 10; $e "VPN Swiss";}
		M6(){ TPUT 9 10; $e "Clean";}
		M7(){ TPUT 10 10; $e "Software";}
		M8(){ TPUT 13 10; $e "Castero";}
		M9(){ TPUT 14 10; $e "Cmus";}
		M10(){ TPUT 15 10; $e "Calendar";}
		M11(){ TPUT 16 10; $e "TW";}
		M12(){ TPUT 17 10; $e "Send Commands";}
		M13(){ TPUT 18 10; $e "Count";}
		M14(){ TPUT 19 10; $e "Xterm";}
		M15(){ TPUT 20 10; $e "ChechFirst";}
		M16(){ TPUT 24 10; $e "DDGR";}
		M17(){ TPUT 25 10; $e "Ranger";}
		M18(){ TPUT 26 10; $e "Monitor";}
		M19(){ TPUT 27 10; $e "Vimwiki";}
		M20(){ TPUT 28 10; $e "EXIT   ";}
		    LM=20
   MENU(){ for each in $(seq 0 $LM);do M${each};done;}
   POS(){ if [[ $cur == up ]];then ((i--));fi
           if [[ $cur == dn ]];then ((i++));fi
           if [[ $i -lt 0   ]];then i=$LM;fi
           if [[ $i -gt $LM ]];then i=0;fi;}
	REFRESH(){ after=$((i+1)); before=$((i-1))
           if [[ $before -lt 0  ]];then before=$LM;fi
           if [[ $after -gt $LM ]];then after=0;fi
           if [[ $j -lt $i      ]];then UNMARK;M$before;else UNMARK;M$after;fi
           if [[ $after -eq 0 ]] || [ $before -eq $LM ];then
           UNMARK; M$before; M$after;fi;j=$i;UNMARK;M$before;M$after;}
	INIT(){ R;HEAD;HEAD2;HEAD3;FOOT;MENU;}
     SC(){ REFRESH;MARK;$S;$b;cur=`ARROW`;}
     ES(){ MARK;$e "ENTER = main menu ";$b;read;INIT;};INIT
	while [[ "$O" != " " ]]; do case $i in


	0) S=M0;SC;if [[ $cur == "" ]];then R;$e "\n$(tmux send-keys -t6 'sudo apt update' Enter)\n";ES;fi;;
	1) S=M1;SC;if [[ $cur == "" ]];then R;$e "\n$(tmux send-keys -t6 'sudo apt upgrade -y ' Enter)\n";ES;fi;;
        2) S=M2;SC;if [[ $cur == "" ]];then R;$e "\n$(tmux send-keys -t6 'nmcli device wifi list' Enter && tmux send-keys -t2 '' Enter)\n";ES;fi;;
        3) S=M3;SC;if [[ $cur == "" ]];then R;$e "\n$(tmux send-keys -t6 'nmcli device wifi connect N20' Enter)\n";ES;fi;;
        4) S=M4;SC;if [[ $cur == "" ]];then R;$e "\n$(tmux send-keys -t6 'nmcli device wifi connect S20' Enter)\n";ES;fi;;
	5) S=M5;SC;if [[ $cur == "" ]];then R;$e "\n$(tmux send-keys -t6 '/usr/bin/protonvpn-cli c ch\#15' Enter)\n";ES;fi;;
	6) S=M6;SC;if [[ $cur == "" ]];then R;$e "\n$(tmux send-keys -t6 'sudo -u batan bash /home/batan/10/menu/clean.sh' Enter)\n";ES;fi;;
	7) S=M7;SC;if [[ $cur == "" ]];then R;$e "\n$(tmux send-keys -t6 'sudo bash /home/batan/10/menu/scripts/fin.sh' Enter)\n";ES;fi;;
		8) S=M8;SC;if [[ $cur == "" ]];then R;$e "\n$(tmux send-keys -t5 'castero' Enter)\n";ES;fi;;
		9) S=M9;SC;if [[ $cur == "" ]];then R;$e "\n$(tmux send-keys -t5 'cmus' Enter )\n";ES;fi;;
		10) S=M10;SC;if [[ $cur == "" ]];then R;$e "\n$(xfce4-terminal --geometry=100x30+0+0 --zoom=-1 --hide-borders --hide-scrollbar --hide-menubar -e 'vim -c :Calendar')\n";ES;fi;;
		11) S=M11;SC;if [[ $cur == "" ]];then R;$e "\n$(xfce4-terminal --geometry=100x30+0+0 --zoom=-1 --hide-borders --hide-scrollbar --hide-menubar -e 'vim -c :TW')\n";ES;fi;;
		12) S=M12;SC;if [[ $cur == "" ]];then R;$e "\n$(tmux send-keys -t4 'while true ;do clear && read -p 'Your Command:     ' abc && tmux send-keys -t1 "$abc" Enter ;done' Enter && tmux selectp -t4)\n";ES;fi;;
		13) S=M13;SC;if [[ $cur == "" ]];then R;$e "\n$(xfce4-terminal --geometry=30x10+0+0 --zoom=-1 --hide-borders --hide-scrollbar --hide-menubar -e 'sudo -u batan bash /home/batan/10/menu/scripts/count.sh')\n";ES;fi;;
		14) S=M14;SC;if [[ $cur == "" ]];then R;$e "\n$(xterm --geometry=50x50-0-0 -e bash -c 'sudo -u batan bash /home/batan/check/xterm.sh')\n";ES;fi;;
		15) S=M15;SC;if [[ $cur == "" ]];then R;$e "\n$(xfce4-terminal --geometry=50x50-0-0 --zoom=-1 --hide-menubar --hide-scrollbar --hide-borders -e 'sudo -u batan bash /home/batan/check/first.sh')\n";ES;fi;;
		16) S=M16;SC;if [[ $cur == "" ]];then R;$e "\n$(xterm -geom 120x75+0+0 -e bash -c "ddgr")\n";ES;fi;;
		17) S=M17;SC;if [[ $cur == "" ]];then R;$e "\n$(tmux send-keys -t1 'ranger' Enter && tmux selectp -t1 )\n";ES;fi;;
		18) S=M18;SC;if [[ $cur == "" ]];then R;$e "\n$(tmux send-keys -t4 'sudo -u batan bash /home/batan/10/menu/scripts/monitor.sh' Enter )\n";ES;fi;;
		19) S=M14;SC;if [[ $cur == "" ]];then R;$e "\n$(xfce4-terminal --geometry=100x50+0+0 --zoom=-1 --zoom=-1 --hide-menubar --hide-scrollbar --hide-borders -e 'vim /home/batan/10/vimwiki/vimwiki/index.wiki')\n";ES;fi;;
		20) S=M20;SC;if [[ $cur == "" ]];then R;exit 0;fi;;

  esac;POS;done
