git clone https://github.com/gorhill/uBlock.git
uBlock.
git clone https://github.com/pasky/speedread.git
speedread.
git clone https://github.com/jahendrie/shalarm.git
shalarm.
git clone https://github.com/vimwiki/vimwiki.git/home/batan/.config/nvim/pack/plugins/start/vimwiki--branchdev
vimwiki--branchdev
git clone https://github.com/farseer90718/vim-taskwarrior~/.config/nvim/pack/plugins/start/vim-taskwarrior
vim-taskwarrior
git clone https://github.com/tools-life/taskwiki.git/home/batan/.config/nvim/pack/plugins/start/taskwiki--branchdev
taskwiki--branchdev
git clone https://github.com/godlygeek/tabular.git/home/batan/.config/nvim/pack/plugins/start/tabular
tabular
git clone https://github.com/mattn/calendar-vim.git/home/batan/.config/nvim/pack/plugins/start/calendar-vim
calendar-vim
git clone https://github.com/majutsushi/tagbar/home/batan/.config/nvim/pack/plugins/start/tagbar
tagbar
git clone https://github.com/powerman/vim-plugin-AnsiEsc/home/batan/.config/nvim/pack/plugins/start/vim-plugin-AnsiEsc
vim-plugin-AnsiEsc
git clone https://github.com/dhruvasagar/vim-table-mode.git/home/batan/.config/nvim/pack/plugins/start/table-mode
table-mode
git clone https://github.com/Shougo/deoplete.nvim.git/home/batan/.config/nvim/pack/plugins/start/deoplete
deoplete
git clone https://github.com/mattn/emmet-vim.git/home/batan/.config/nvim/pack/plugins/start/emmet-vim
emmet-vim
git clone https://github.com/dense-analysis/ale.git/home/batan/.config/nvim/pack/plugins/start/ale
ale
git clone https://github.com/othree/html5.vim.git/home/batan/.config/nvim/pack/plugins/start/html5.vim
html5.vim
git clone https://github.com/tpope/vim-surround.git/home/batan/.config/nvim/pack/plugins/start/surround-vim
surround-vim
git clone https://github.com/prabirshrestha/vim-lsp/home/batan/.config/nvim/pack/plugins/start/vim-lsp.git
vim-lsp.git
git clone https://github.com/rhysd/vim-lsp-ale.git/home/batan/.config/nvim/pack/plugins/start/vim-lsp-ale.git
vim-lsp-ale.git
git clone https://github.com/prettier/prettier.git~/.config/nvim/pack/plugins/start/prettier/
prettier/
git clone https://github.com/Shougo/unite.vim.git~/.config/nvim/pack/plugins/start/unite.vim
unite.vim
git clone https://github.com/LukeSmithxyz/mutt-wizard
mutt-wizard
git clone https://github.com/pasky/speedread.git
speedread.git
git clone https://github.com/jahendrie/shalarm.git
shalarm.git
git clone https://github.com/vinceliuice/Graphite-gtk-theme.git
Graphite-gtk-theme.git
git clone https://github.com/rafi/awesome-vim-colorschemes.git/home/batan/.config/nvim/pack/plugins/start/awsome-vim-colorschemes
awsome-vim-colorschemes
git clone https://github.com/vimwiki/vimwiki.git/home/batan/.vim/pack/plugins/start/vimwiki--branchdev
vimwiki--branchdev
git clone https://github.com/farseer90718/vim-taskwarrior/home/batan/.vim/pack/plugins/start/vim-taskwarrior
vim-taskwarrior
git clone https://github.com/tools-life/taskwiki.git/home/batan/.vim/pack/plugins/start/taskwiki--branchdev
taskwiki--branchdev
git clone https://github.com/godlygeek/tabular.git/home/batan/.vim/pack/plugins/start/tabular
tabular
git clone https://github.com/mattn/calendar-vim.git/home/batan/.vim/pack/plugins/start/calendar-vim
calendar-vim
git clone https://github.com/majutsushi/tagbar/home/batan/.vim/pack/plugins/start/tagbar
tagbar
git clone https://github.com/powerman/vim-plugin-AnsiEsc/home/batan/.vim/pack/plugins/start/vim-plugin-AnsiEsc
vim-plugin-AnsiEsc
git clone https://github.com/dhruvasagar/vim-table-mode.git/home/batan/.vim/pack/plugins/start/table-mode
table-mode
git clone https://github.com/Shougo/deoplete.nvim.git/home/batan/.vim/pack/plugins/start/deoplete
deoplete
git clone https://github.com/mattn/emmet-vim.git/home/batan/.vim/pack/plugins/start/emmet-vim
emmet-vim
git clone https://github.com/dense-analysis/ale.git/home/batan/.vim/pack/plugins/start/ale
ale
git clone https://github.com/othree/html5.vim.git/home/batan/.vim/pack/plugins/start/html5.vim
html5.vim
git clone https://github.com/tpope/vim-surround.git/home/batan/.vim/pack/plugins/start/surround-vim
surround-vim
git clone https://github.com/prabirshrestha/vim-lsp/home/batan/.vim/pack/plugins/start/vim-lsp.git
vim-lsp.git
git clone https://github.com/rhysd/vim-lsp-ale.git/home/batan/.vim/pack/plugins/start/vim-lsp-ale.git
vim-lsp-ale.git
git clone https://github.com/prettier/prettier.git/home/batan/.vim/pack/plugins/start/prettier/
prettier/
git clone https://github.com/Shougo/unite.vim.git/home/batan/.vim/pack/plugins/start/unite.vim
unite.vim
git clone https://github.com/rafi/awesome-vim-colorschemes.git/home/batan/.vim/pack/plugins/start/awsome-vim-colorschemes
awsome-vim-colorschemes
git clone https://github.com/vimwiki/vimwiki.git/home/batan/.config/nvim/pack/plugins/start/vimwiki--branchdev
vimwiki--branchdev
git clone https://github.com/farseer90718/vim-taskwarrior/home/batan/.config/nvim/pack/plugins/start/vim-taskwarrior
vim-taskwarrior
git clone https://github.com/tools-life/taskwiki.git/home/batan/.config/nvim/pack/plugins/start/taskwiki--branchdev
taskwiki--branchdev
git clone https://github.com/godlygeek/tabular.git/home/batan/.config/nvim/pack/plugins/start/tabular
tabular
git clone https://github.com/mattn/calendar-vim.git/home/batan/.config/nvim/pack/plugins/start/calendar-vim
calendar-vim
git clone https://github.com/majutsushi/tagbar/home/batan/.config/nvim/pack/plugins/start/tagbar
tagbar
git clone https://github.com/powerman/vim-plugin-AnsiEsc/home/batan/.config/nvim/pack/plugins/start/vim-plugin-AnsiEsc
vim-plugin-AnsiEsc
git clone https://github.com/dhruvasagar/vim-table-mode.git/home/batan/.config/nvim/pack/plugins/start/table-mode
table-mode
git clone https://github.com/Shougo/deoplete.nvim.git/home/batan/.config/nvim/pack/plugins/start/deoplete
deoplete
git clone https://github.com/mattn/emmet-vim.git/home/batan/.config/nvim/pack/plugins/start/emmet-vim
emmet-vim
git clone https://github.com/dense-analysis/ale.git/home/batan/.config/nvim/pack/plugins/start/ale
ale
git clone https://github.com/othree/html5.vim.git/home/batan/.config/nvim/pack/plugins/start/html5.vim
html5.vim
git clone https://github.com/tpope/vim-surround.git/home/batan/.config/nvim/pack/plugins/start/surround-vim
surround-vim
git clone https://github.com/prabirshrestha/vim-lsp/home/batan/.config/nvim/pack/plugins/start/vim-lsp.git
vim-lsp.git
git clone https://github.com/rhysd/vim-lsp-ale.git/home/batan/.config/nvim/pack/plugins/start/vim-lsp-ale.git
vim-lsp-ale.git
git clone https://github.com/prettier/prettier.git/home/batan/.config/nvim/pack/plugins/start/prettier/
prettier/
git clone https://github.com/Shougo/unite.vim.git/home/batan/.config/nvim/pack/plugins/start/unite.vim
unite.vim
