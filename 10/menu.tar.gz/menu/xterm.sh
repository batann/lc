#!/usr/bin/env sh


Green='\033[0;32m'
Cyan='\033[0;36m'
Yellow='\033[1;33m'
NC='\033[0m'


cd $HOME/100/check/
/usr/bin/xterm -geom 50x40-0-0 -e "transset -a && sudo -u batan bash $HOME/Documents/check/first.sh"
