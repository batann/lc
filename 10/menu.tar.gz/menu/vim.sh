#!/bin/bash
cmd=(dialog --backtitle "Github" --title "Nvim Plugins" --checklist "Select either the individual Plugins or a complete bundle:" 0 0 30)
