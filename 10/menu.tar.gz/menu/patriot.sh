#!/bin/bash
#
#
rm temporary
clear
yad --dnd --geometry=800x500+0+0 --text-align=center --text="Your Directories and Files Here:">>termporary
bcd=(cat tamporary|sed 's!--file://!!g')

tar vfcz patriot.tar.gz $bcd
mv patriot.tar.gz /media/batan/100


