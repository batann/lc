# Date  :       219
# Author:	fairdinkum batan
#!/bin/bash
xfce4-terminal --geometry='200x57-0+0' --zoom=-1 --color-bg='Black' -e "tmux new-session \; splitw -v -p60 'sudo -u batan bash /home/batan/10/menu/scripts/monitor.sh' \; splitw -h -p 70 'sudo -u batan bash /home/batan/10/menu/menu1.sh' \; splitw -h -p78 \; splitw -v -p20 'watch -n1 -t ps -T' \; selectp -t0 \; splitw -h -p72 \; splitw -v -p30 'sudo -u batan bash /home/batan/10/menu/scripts/a.sh' \; selectp -t1 \; splitw -h -p29 'sudo -u batan bash /home/batan/10/menu/menu2.sh' \; selectp -t5 \; send-keys -t5 ' ' Enter \;"
