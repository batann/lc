 #/bin/bash


		E='echo -e';e='echo -en';trap "R;exit" 2
		ESC=$( $e "\e")
		TPUT(){ $e "\e[${1};${2}H";}
		CLEAR(){ $e "\ec";}
		CIVIS(){ $e "\e[?25l";}
		DRAW(){ $e "\e%@\e(0";}
		WRITE(){ $e "\e(B";}
		MARK(){ $e "\e[7m";}
		UNMARK(){ $e "\e[27m";}
		R(){ CLEAR ;stty sane;$e "\ec\e[30;44m\e[J";};
		HEAD(){ DRAW
			for each in $(seq 1 30);do
			$E " x                      x"
			done
			WRITE;MARK;TPUT 1 5
			$E "  Usefull Software  ";UNMARK;}
			i=0; CLEAR; CIVIS;NULL=/dev/null
			HEAD2(){ MARK;TPUT 11 5
			printf " Custom Scripts    ";UNMARK;}
			HEAD3(){ MARK;TPUT 22 5
			printf " Ba7an@tutanota.com";UNMARK;}
			FOOT(){ MARK;TPUT 30 5
			printf " Privacy Matters   ";UNMARK;}
			ARROW(){ read -s -n3 key 2>/dev/null >&2
			if [[ $key = $ESC[A ]];then echo up;fi
			if [[ $key = $ESC[B ]];then echo dn;fi;}

		M0(){ TPUT 3 10; $e "Update";}
	    	M1(){ TPUT 4 10; $e "Upgrade";}
	    	M2(){ TPUT 5 10; $e "List Networks";}
	    	M3(){ TPUT 6 10; $e "Connect N20";}
	    	M4(){ TPUT 7 10; $e "Connect S20";}
	    	M5(){ TPUT 8 10; $e "Proton ch#15";}
		M6(){ TPUT 9 10; $e "ddgr xclip";}
		M7(){ TPUT 10 10; $e "Postinstall";}
		M8(){ TPUT 13 10; $e "Note";}
		M9(){ TPUT 14 10; $e "Chess";}
		M10(){ TPUT 15 10; $e "Calendar";}
		M11(){ TPUT 16 10; $e "TW";}
		M12(){ TPUT 17 10; $e "VimL";}
		M13(){ TPUT 18 10; $e "Ranger";}
		M14(){ TPUT 19 10; $e "Vimwiki";}
		M15(){ TPUT 20 10; $e "SplitV";}
		M16(){ TPUT 24 10; $e "DDGR";}
		M17(){ TPUT 25 10; $e "SplitWindow";}
		M18(){ TPUT 26 10; $e "F - ";}
		M19(){ TPUT 27 10; $e "E - ";}
		M20(){ TPUT 28 10; $e "EXIT   ";}
		    LM=20
   MENU(){ for each in $(seq 0 $LM);do M${each};done;}
   POS(){ if [[ $cur == up ]];then ((i--));fi
           if [[ $cur == dn ]];then ((i++));fi
           if [[ $i -lt 0   ]];then i=$LM;fi
           if [[ $i -gt $LM ]];then i=0;fi;}
	REFRESH(){ after=$((i+1)); before=$((i-1))
           if [[ $before -lt 0  ]];then before=$LM;fi
           if [[ $after -gt $LM ]];then after=0;fi
           if [[ $j -lt $i      ]];then UNMARK;M$before;else UNMARK;M$after;fi
           if [[ $after -eq 0 ]] || [ $before -eq $LM ];then
           UNMARK; M$before; M$after;fi;j=$i;UNMARK;M$before;M$after;}
	INIT(){ R;HEAD;HEAD2;HEAD3;FOOT;MENU;}
     SC(){ REFRESH;MARK;$S;$b;cur=`ARROW`;}
     ES(){ MARK;$e "ENTER = main menu ";$b;read;INIT;};INIT
	while [[ "$O" != " " ]]; do case $i in


        0) S=M0;SC;if [[ $cur == "" ]];then R;$e "\n$(tmux send-keys -t1 'sudo apt update' Enter )\n";ES;fi;;
	1) S=M1;SC;if [[ $cur == "" ]];then R;$e "\n$(tmux send-keys -t1 'sudo apt upgrade -y' Enter )\n";ES;fi;;
        2) S=M2;SC;if [[ $cur == "" ]];then R;$e "\n$(tmux send-keys -t1 'nmcli device wifi list' Enter && tmux send-keys -t1 'q' Enter )\n";ES;fi;;
        3) S=M3;SC;if [[ $cur == "" ]];then R;$e "\n$(tmux send-keys -t1 'nmcli device wifi connect N20' Enter )\n";ES;fi;;
        4) S=M4;SC;if [[ $cur == "" ]];then R;$e "\n$(tmux send-keys -t1 'nmcli device wifi connect S20' Enter )\n";ES;fi;;
        5) S=M5;SC;if [[ $cur == "" ]];then R;$e "\n$(tmux send-keys -t1 '/usr/bin/protonvpn-cli c ch\#15' Enter )\n";ES;fi;;
		6) S=M6;SC;if [[ $cur == "" ]];then R;$e "\n$(xfce4-terminal --geometry=100x-1-50+50 --color-bg=Green --color-text=Black -e 'ddgr -n1 -x -w youtube.com|sed -n '2p'|xclip -selec c')\n";ES;fi;;
		7) S=M7;SC;if [[ $cur == "" ]];then R;$e "\n$(tmux send-keys -t1 'sudo bash /home/batan/16/sh/fin.sh' Enter)\n";ES;fi;;
		8) S=M8;SC;if [[ $cur == "" ]];then R;$e "\n$(xfce4-terminal --geometry=80x50+1300-0 --color-bg=Black --color-text=Green -e 'vim +start /home/batan/16/note/1000.txt')\n";ES;fi;;
		9) S=M9;SC;if [[ $cur == "" ]];then R;$e "\n$(falkon chess.com)\n";ES;fi;;
		10) S=M10;SC;if [[ $cur == "" ]];then R;$e "\n$(xfce4-terminal --geometry=100x30+0+0 --hide-borders --hide-scrollbar --hide-menubar -e 'vim -c :Calendar')\n";ES;fi;;
		11) S=M11;SC;if [[ $cur == "" ]];then R;$e "\n$(xfce4-terminal --geometry=100x30+0+0 --hide-borders --hide-scrollbar --hide-menubar -e 'vim -c :TW')\n";ES;fi;;
		12) S=M12;SC;if [[ $cur == "" ]];then R;$e "\n$(xfce4-terminal --geometry=100x30+0+0 --hide-borders --hide-scrollbar --hide-menubar -e 'vim -c :Lexplore')\n";ES;fi;;
		13) S=M13;SC;if [[ $cur == "" ]];then R;$e "\n$(xfce4-terminal --geometry=100x30+0+0 --hide-borders --hide-scrollbar --hide-menubar -e 'ranger')\n";ES;fi;;
		14) S=M14;SC;if [[ $cur == "" ]];then R;$e "\n$(xfce4-terminal --geometry=100x50+0+0 --zoom=-1 --hide-menubar --hide-scrollbar --hide-borders -e 'vim /home/batan/16/vimwiki/index.wiki')\n";ES;fi;;
		15) S=M15;SC;if [[ $cur == "" ]];then R;$e "\n$(tmux killp -t2 \; splitw -h -p70 'fortune' )\n";ES;fi;;
		16) S=M16;SC;if [[ $cur == "" ]];then R;$e "\n$(\read abc && bcd=$(ddgr -n1 --np -x -w en.wikipedia.org $abc) && tmux send-keys -t5 "echo $bcd" Enter )\n";ES;fi;;
		17) S=M17;SC;if [[ $cur == "" ]];then R;$e "\n$(tmux splitw -t1 -h -p70)\n";ES;fi;;
		18) S=M18;SC;if [[ $cur == "" ]];then R;$e "\n$(echo 'Really,Peter'|festival --tts)\n";ES;fi;;
		19) S=M19;SC;if [[ $cur == "" ]];then R;$e "\n$(printf 'Blah Blah')\n";ES;fi;;
		20) S=M20;SC;if [[ $cur == "" ]];then R;exit 0;fi;;

  esac;POS;done
