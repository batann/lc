# Yad

### Yad EG. {#yad_eg.}

[`Yad`` ``eg`](Yad_eg "wikilink")

### Yad Dynamic \--list {#yad_dynamic___list}

[Dynamic List](Dynamic_List "wikilink")
