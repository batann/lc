#!/bin/bash
#############################################################
#name:
#description:
#author: Fairdinkum Batan
#date:
#############################################################



clear
# Specify the directory to search for duplicates
directory="/home/batan/"

# Use find to get a list of all files in the directory
find "$directory" -type f -exec md5sum {} + |
  # Use awk to extract the checksum and filename, then sort by checksum
  awk '{print $1,$2}' | sort |
  # Use uniq to find and print duplicate checksums
  uniq -d --check-chars=32 |
  # Use join to display the corresponding filenames
  join - <(sort "$directory"/* -o -) -o '2.2' --check-order
