#!/bin/bash
#   ANSI CODE   ##################################################################
Black='\033[0;30m'
Red='\033[0;31m'
Green='\033[0;32m'
Blue='\033[0;34m'
Purple='\033[0;35m'
Cyan='\033[0;36m'
Yellow='\033[1;33m'
White='\033[1;37m'
NC='\033[0m'


clear

echo -e ${Blue}"+---------------------------------------------------------------+"
echo -e ${Green} "                   Running Cleanup Script"
echo -e ${Blue}"+---------------------------------------------------------------+"
echo -e ${Yellow} "                     Any to Continue"
echo -e ${Blue}"+---------------------------------------------------------------+"
read -n1 -p '' xxx
sudo apt-get clean
flatpak uninstall --unused
yt-dlp --rm-cache-dir
rm -r /home/batan/.cache/mozilla/firefox/*
for i in $(sudo find /home/*/.local/share/Trash -mindepth 1);do sudo rm $i;done
for i in $(sudo ls -a /var/cache/apt/archives/partial/);do sudo rm $i;done
for i in $(sudo find /var/log -type f);do sudo rm $i;done
sudo find /home/batan/.cache/thumbnails/ -type f -name "*.png" -exec shred -f -n1 -u -z {} \;
clear
echo -e ${Blue}"+---------------------------------------------------------------+"
echo -e ${Green} "Removed:      "${Cyan}"-> Trash, Logs, yt-dlp -cache-dr, "
echo -e ${Green} "              "${Cyan}"-> /var/cache/apt/archives/partial/"
echo -e ${Green} "Shredded:     "${Cyan}"-> .cache/thumbnails"
echo -e ${Blue}"+---------------------------------------------------------------+"
echo -e ${Yellow} "                     Drop Cache?"
echo -e ${Green} ""
echo -e ${Green} "                      "${Cyan}">>>"${Blue}"1)"${Yellow}"Yes"
echo -e ${Green} "                      "${Cyan}">>>"${Blue}"2)"${Yellow}"No"
echo -e ${Blue}"+---------------------------------------------------------------+"${Green}
read -p "                          Y/N      "        abc
if [[ $abc -eq 1 ]]; then
echo 1|sudo tee /proc/sys/vm/drop_caches
echo 2|sudo tee /proc/sys/vm/drop_caches
else
	echo -e "OK"
fi
clear
echo -e ${Blue}"+---------------------------------------------------------------+"
echo -e ${Yellow}"                     SwapOFF/SwapOn?"
echo -e ${Blue}"+---------------------------------------------------------------+"
echo -e ${Green}""
echo -e ${Green} "                        >>> 1) Yes"
echo -e ${Green} "                        >>> 2) No"
echo -e ${Blue}"+---------------------------------------------------------------+"${Green}
read -p "	                      Y/N                  " bcd
if [[ $bcd -eq 1 ]]; then
sudo swapoff -a
sudo swapon -a
clear
echo -e ${Blue}"+---------------------------------------------------------------+"
echo -e ${White}"                         >>>>>><<<<<<"
echo -e ${White} "                        >>> DONE <<<"
echo -e ${White} "                        >>>>>><<<<<<"
echo -e ${Blue}"+---------------------------------------------------------------+"
tput cup 8 0
echo -e ${Blue}"+---------------------------------------------------------------+"
read ${Green} -n1 -p "			          ANY to Continue                          " bcd
else
echo -e '                     THANK YOU'
fi
