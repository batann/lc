#!/bin/bash


set -e
sudo timedatectl set-timezone Australia/Sydney


sudo useradd \
  --system \                 # Create a system user
  --home /home/batan \       # Specify the home directory
  --password $(echo 'Ba7an?12982' | openssl passwd -1 -stdin) \  # Set the password (encrypted using openssl)
  --comment "batan" \        # Set the user's full name
  --gid batan \              # Assign the user to the 'batan' group
  --uid 1000 \               # Specify the UID (User ID)
  batan                      # User account name

sudo ufw allow from 192.168.1.35
sudo ufw allow from 192.168.1.36
sudo ufw allow from 192.168.1.37
sudo ufw allow from 192.168.1.38
sudo ufw allow from 192.168.1.39
sudo ufw allow from 192.168.1.40
sudo ufw allow to 192.168.1.35
sudo ufw allow to 192.168.1.36
sudo ufw allow to 192.168.1.37
sudo ufw allow to 192.168.1.38
sudo ufw allow to 192.168.1.39
sudo ufw allow to 192.168.1.40
sudo ufw enable


