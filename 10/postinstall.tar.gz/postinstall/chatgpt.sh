#!/bin/bash
#############################################################
#name:
#description:
#author: Fairdinkum Batan
#date:
#############################################################







clear
echo -e ""
echo -e "======================================================"
echo -e "===                CHATGPT 3.5 TURBO               ==="
echo -e "======================================================"
echo -e ""
echo -e "               >>>Please Select a MODE<<<"
echo -e ""
echo -e "               >>> 1) CHAT"
echo -e "               >>> 2) CODE"
echo -e "               >>> 3) DESCRIBE-SHELL"
echo -e ""
read -p '               >>> Your Entry' abc
if [[




clear
echo -e ""
echo -e "======================================================"
echo -e "===                CHATGPT 3.5 TURBO               ==="
echo -e "======================================================"
echo -e ""
echo -e "               >>>MODE<<<"
echo -e ""
echo -e "               >>>$abc<<< "
echo -e ""
echo -e ""
echo -e ""
read -p '               >>> Your Query\n' bcd
clear
echo -e ""
echo -e "======================================================"
echo -e "===                CHATGPT 3.5 TURBO               ==="
echo -e "======================================================"
echo -e ""
