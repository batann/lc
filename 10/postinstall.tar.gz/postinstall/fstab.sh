#!/bin/bash
clear
echo "Update fstab with data partition?"
echo ">>> 1) Yes"
echo ">>> 2) No"
tput cup 5 15
read -p '1/2' xxx
if [[ $xxx -eq 2 ]]; then
clear
echo "Alright"
exit 0
else

abc=$(sudo fdisk -l|grep 'sda'|grep -v 'sda1'|grep FAT|cut -c 1-9)
bcd=$(sudo blkid $abc|awk '{print $4}')
cde=$(echo $bcd|sed 's!$! /media/batan/100/ vfat defaults,noatime,noexec,nofail,rw,uid=batan,umask=0000,dmask=0011 0 0')
fi

echo $cde
touch /home/batan/fstab
sudo cat /etc/fstab >> /home/batan/fstab
echo -e "$cde">>/home/batan/fstab
sudo chown -R root:root /home/batan/fstab
	sudo mv /etc/fstab /etc/fstab.bak.$(date +%H:%M)
sudo mv /home/batan/fstab /etc/
clear
if [[ -d /media/batan/100/ ]]; then
sudo chown -R batan:batan /media/batan/100
else
sudo mkdir /media/batan/100/
sudo chown -R batan:batan /media/batan/100
echo "DONE"
fi
