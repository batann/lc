#!/bin/bash
#############################################################
#name:
#description:
#author: Fairdinkum Batan
#date:		345
#############################################################


clear
touch /home/batan/.megarc
echo "[Login]">>/home/batan/.megarc
echo "Username=tel.petar@gmail.com">>/home/batan/.megarc
echo "Password=Ba7an?12982">>/home/batan/.megarc
clear
