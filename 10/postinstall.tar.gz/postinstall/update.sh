#!/bin/bash
#############################################################
#name:
#description:
#author: Fairdinkum Batan
#date:
#############################################################
Black='\033[0;30m'
Red='\033[0;31m'
Green='\033[0;32m'
Blue='\033[0;34m'
Purple='\033[0;35m'
Cyan='\033[0;36m'
Yellow='\033[1;33m'
White='\033[1;37m'

clear
sudo apt update && sudo apt upgrade -y
clear
echo -e ${Yellow}'+----------------------------------------------------+'
echo -e ${Green} '                  Systen is up to date                '
echo -e ${Yellow}'+----------------------------------------------------+'
tput cup 3 19
read -n1 -p 'Any Button to Exit'
