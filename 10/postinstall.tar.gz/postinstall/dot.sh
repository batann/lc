#!/bin/bash
#   ANSI CODE   ##################################################################
Black="\033[0;30m"
Red="\033[0;31m"
Green="\033[0;32m"
Blue="\033[0;34m"
Purple="\033[0;35m"
Cyan="\033[0;36m"
Yellow="\033[1;33m"
White="\033[1;37m"
NC="\033[0m"
###################################################################
clear
echo -e ${Blue}"+--------------------------------------------------+"
echo -e ${Green} $(date +%H:%M)
echo -e ${NC}
echo -e ${Green} "Making required directories"
echo -e ${Blue}"+--------------------------------------------------+"
read -n1 -p 'Press Any Key to Continue' abc
mkdir -p /home/batan/.vim/pack/plugins/start/vimwiki/autoload/vimwiki
mkdir -p /home/batan/.config/nvim
mkdir -p /home/batan/.cachwe/calendar.vim/
clear
echo -e ${Blue}"+--------------------------------------------------+"
echo -e ${Green} $(date +%H:%M)
echo -e ${NC}
echo -e ${Green} "Moving the existing and copying New dot Files"
echo -e ${Blue}"+--------------------------------------------------+"
read -n1 -p 'Press Any Key to Continue' abc
if [ -f /home/batan/.bashrc ]; then
mv /home/batan/.bashrc /home/batan/.bashrc.bak
fi
if [ -f /home/batan/.bashrc.aliases ]; then
mv /home/batan/.bashrc.aliases /home/batan/.bashrc.aliases.bak
fi
if [ -f /home/batan/.vim/pack/plugins/start/vimwiki/autoload/vimwiki/default.tpl ]; then
mv /home/batan/.vim/pack/plugins/start/vimwiki/autoload/vimwiki/default.tpl /home/batan/.vim/pack/plugins/start/vimwiki/autoload/vimwiki/default.tpl.bak
fi
cp /home/batan/dot/bashrc /home/batan/.bashrc
cp /home/batan/dot/bashrc.aliases /home/batan/.bashrc.aliases
cp /home/batan/dot/credentials.vim /home/batan/.cache/calendar.vim/credentials.vim
cp /home/batan/dot/default.tpl /home/batan/.vim/pack/plugins/start/vimwiki/autoload/vimwiki/default.tpl
cp /home/batan/dot/init.vim /home/batan/.config/nvim/init.vim
cp /home/batan/dot/layout.kdl /home/batan/.layout.kdl
cp /home/batan/dot/megarc /home/batan/.megarc
cp /home/batan/dot/music.kdl /home/batan/.music.kdl
cp /home/batan/dot/rss.opml /home/batan/.rss.opml
cp /home/batan/dot/strider2.kdl /home/batan/.strider2.kdl
cp /home/batan/dot/strider.kdl /home/batan/.strider.kdl
cp /home/batan/dot/taskrc /home/batan/.taskrc
cp /home/batan/dot/tkremindrc /home/batan/.tkremindrc
cp /home/batan/dot/tmux.config /home/batan/.tmux.config
cp /home/batan/dot/userfile /home/batan/.userfile
cp /home/batan/dot/vimrc /home/batan/.vimrc
cp /home/batan/dot/xboardrc /home/batan/.xboardrc

echo -e ${Blue}"+--------------------------------------------------+"
echo -e ${Green} $(date +%H:%M)
echo -e ${NC}
echo -e ${Green} "                   DONE"
echo -e ${Blue}"+--------------------------------------------------+"
exit
