#!/bin/bash
#############################################################
#name:
#description:
#author: Fairdinkum Batan
#date:
#############################################################


rm temporary
clear
abc=$(yad --dnd --geometry=700x500-0-0 --text="Your Files and Directories Here")
bcd=$(echo $abc|sed 's!file://!!g')
echo $bcd

tar vfcz backup.$(date +%j).tar.gz $bcd

mv backup.$(date +%j).tar.gz /media/batan/100/
