#!/bin/bash
#############################################################
#name: download.sh
#description:
#author: Fairdinkum Batan
#date:
#############################################################



abc=$(yad --entry --width=400 --entry-label="URL")
	yt-dlp $abc
