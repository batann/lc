#!/bin/bash
clear
sudo apt install taskwarrior timewarrior vit
clear
echo "Installing TaskNote"
mkdir /home/batan/.task
cd /home/batan/.task
git clone https://github.com/mikebobroski/tasknote.git
git clone https://github.com/kellya/mutt2tw.git
git clone https://github.com/flickerfly/taskwarrior-notifications.git
cd tasknote
sudo chmod a+x tasknote
sudo sed -i '47s/.*/FOLDER="/home/batan/10/tasks/notes/"' tasknote
sudo sed -i '64s/.*/EXT=".wiki"/' tasknote
sudo cp /home/batan/tasknote/tasknote /usr/bin/
#"taskwarrior send email notification
sudo apt install neomutt

clear
dialog --title "Application Installed" --colors --msgbox "\n\Zb\Z1Taskwarrior\nTimewarrior\nVit\n\n\Zn\Z3Where installed from os repos\nadditional installs from github" 0 0

exit 0
