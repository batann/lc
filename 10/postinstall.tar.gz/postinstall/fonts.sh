#!/bin/bash
#############################################################
#name:
#description:
#author: Fairdinkum Batan
#date:
#############################################################

clear
megaget /Root/fonts.tar.gz
sudo tar fxz /home/natan/fonts.tar.gz --directoory=/usr/share/fonts/
clear
