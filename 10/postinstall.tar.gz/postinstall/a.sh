#!bin/bash
clear
echo -e "${Yellow}+------------------------------------------------------------------+"

tput cup 2 0
options=$(ls /home/batan/10/menu/scripts/); select software in ${options[@]}; do clear && tput cup 20 0 && echo -e "+-----------------------------------------------------------+" && sudo -u batan bash /home/batan/10/menu/scripts/$software ; done
