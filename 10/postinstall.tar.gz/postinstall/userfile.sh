#!/bin/bash
userfile="$HOME/.userfile.md"
if [ $# -eq 0 ] ; then
	more $userfile| ${PAGER:-more}
	fi
	exit 0
